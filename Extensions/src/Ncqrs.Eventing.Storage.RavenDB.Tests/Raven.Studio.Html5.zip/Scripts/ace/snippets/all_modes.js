define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./all_modes.snippets");
exports.scope = "all_modes";

});
